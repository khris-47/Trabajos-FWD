import Routing from "./routes/Routing"
//import './App.css'

function App() {

  return (
      <Routing ></Routing>
  )
}

export default App
