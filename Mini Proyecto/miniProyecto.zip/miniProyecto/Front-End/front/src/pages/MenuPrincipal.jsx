import React from 'react'

import Menu from '../components/Menu'

function MenuPrincipal() {
  return (
    <Menu></Menu>
  )
}

export default MenuPrincipal