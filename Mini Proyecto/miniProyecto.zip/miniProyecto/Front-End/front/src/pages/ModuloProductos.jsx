import React from 'react'
import FormularioProducto from '../components/FormularioProducto'

function ModuloProductos() {
  return (
    
    <FormularioProducto></FormularioProducto>

  )
}

export default ModuloProductos