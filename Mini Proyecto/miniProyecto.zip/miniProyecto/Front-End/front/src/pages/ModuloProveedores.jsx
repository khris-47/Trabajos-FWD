import React from 'react'
import FormularioProveedores from '../components/FormularioProveedores'

function ModuloProveedores() {
  return (
    <FormularioProveedores></FormularioProveedores>
  )
}

export default ModuloProveedores