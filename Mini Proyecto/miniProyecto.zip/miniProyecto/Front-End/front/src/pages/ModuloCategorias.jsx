import React from 'react'
import FormularioCategorias from '../components/FormularioCategorias'

function ModuloCategorias() {
  return (
    <FormularioCategorias></FormularioCategorias>
  )
}

export default ModuloCategorias