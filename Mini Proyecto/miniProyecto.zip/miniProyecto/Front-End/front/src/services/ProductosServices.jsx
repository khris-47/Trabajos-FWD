const baseUrl = "http://localhost:8000/api/producto/";


// Metodo Get
export async function obtenerProductos() {
    try {
        // realizamos la solicitud get al endpoint
        const response = await fetch(baseUrl, {
            method: "GET",
            headers: {
                "Content-Type": "application/json" //indicacmos que se espera un Json
            }
        });

        //esperamos la respuesta
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Error al obtener productos: ${errorText}`);
        }

        //convertimos la respusta a json y a devolvemos
        const data = await response.json();
        return data;

    } catch (error) {
        console.error('Error en la petición de productos:', error);
        throw error;
    }
}

// Metodo Post
export const crearProducto = async (producto) => {
    try {
        const response = await fetch(baseUrl, {
            method: "POST", 
            headers: {
                "Content-Type": "application/json", //cuerpo en formato Json
            },
            body: JSON.stringify(producto), //convertir el objeto a json
        });

        //espera la respuesta
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(JSON.stringify(errorData));
        }

        //enviar la respuesta
        return await response.json();
    } catch (error) {
        console.error("Error al crear producto:", error);
        throw error;
    }
};

// Metodo Put
export const actualizarProducto = async (id, producto) => {
    try {
        const response = await fetch(`${baseUrl}${id}/`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json", 
            },
            body: JSON.stringify(producto),//convertir el objeto a json
        });

        //esperar la respuesat
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(JSON.stringify(errorData));
        }

        return await response.json();
    } catch (error) {
        console.error("Error al actualizar producto:", error);
        throw error;
    }
};

//metodo delete
export const eliminarProducto = async (id) => {
    try {
        const response = await fetch(`${baseUrl}${id}/`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
            },
        });

        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Error al eliminar producto: ${errorText}`);
        }

        return true;
    } catch (error) {
        console.error("Error al eliminar producto:", error);
        throw error;
    }
};