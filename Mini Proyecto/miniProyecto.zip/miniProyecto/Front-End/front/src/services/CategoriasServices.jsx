
// una constante con la url de la Api
const baseUrl = "http://127.0.0.1:8000/api/categoria/";



// funcion para cargar la lista
export async function obtenerCategorias() {
    try {
        // realizamos la solicitud get al endpoint
        const response = await fetch(baseUrl, {
            method: "GET",
            headers: {
                "Content-Type": "application/json" //se espera un json
            }
        });

        //esperamos la respuesta
        if (!response.ok) {
            const errorText = await response.text();
            throw new Error(`Error al obtener la categoria: ${errorText}`);
        }

        //se convierta la respuesta a json
        const data = await response.json();
        return data;
        
    } catch (error) {
        console.error('Error en la peticion de categoria:', error);
        throw error;
    }
}

// funcion encargada del Post
export async function crearCategoria(categoria) {
    try {
        const response = await fetch(baseUrl, {
            method: "POST",  // metodo de la solicitud
            headers: { "Content-Type": "application/json" },  // establece el tipo de contenido
            body: JSON.stringify(categoria)  // convierte el objeto categorra a JSON
        });
        if (!response.ok) {  // verifica  la respuesta 
            throw new Error('Error al crear la categoria'); 
        }
        return await response.json();  // Devuelve los datos en formato JSON
    } catch (error) {
        alert(error.message);  // muestra una alerta con el mensaje de error
        console.error("Error en crearCategoria:", error);  
    }
}

// funcion encargada del PUT (update)
export async function actualizarCategoria(id, categoria) {
    try {
        const response = await fetch(`${baseUrl}${id}/`, {
            method: "PUT",  // metodo de la solicitud
            headers: { "Content-Type": "application/json" },  // establece el tipo de contenido
            body: JSON.stringify(categoria)  // convierte el objeto a JSON
        });
        if (!response.ok) {  // verifica  la respuesta 
            throw new Error('Error al actualizar la categoría');  
        }
        return await response.json();  // devuelve los datos en formato JSON
    } catch (error) {
        alert(error.message);  
        console.error("Error en actualizarCategoria:", error);  
    }
}

// funcion encargada del DELETE
export async function eliminarCategoria(id) {
    try {
        const response = await fetch(`${baseUrl}${id}/`, {
            method: "DELETE"  // método de la solicitud
        });
        if (!response.ok) {  // erifica la respuesta 
            throw new Error('Error al eliminar la categoría');  
        }
    } catch (error) {
        alert(error.message);  
        console.error("Error en eliminarCategoria:", error);  
    }
}

