const baseUrl = "http://127.0.0.1:8000/api/proveedor/";



export async function obtenerProveedor() {
    const response = await fetch(baseUrl);
    return await response.json();
}

export async function crearProveedor(proveedor) {
    const response = await fetch(baseUrl, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(proveedor)
    });
    return await response.json();
}

export async function actualizarProveedor(id, proveedor) {
    const response = await fetch(`${baseUrl}${id}/`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(proveedor)
    });
    return await response.json();
}

export async function eliminarProveedor(id) {
    await fetch(`${baseUrl}${id}/`, {
        method: "DELETE"
    }).then(res => {
        if (!res.ok) {
            throw new Error('Error al eliminar el proveedor');
        }
    });
}