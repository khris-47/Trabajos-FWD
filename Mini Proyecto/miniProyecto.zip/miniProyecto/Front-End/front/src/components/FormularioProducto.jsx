import React, { useEffect, useState } from 'react';
import { obtenerProductos, crearProducto, actualizarProducto, eliminarProducto } from '../services/ProductosServices';
import { obtenerCategorias } from '../services/CategoriasServices';
import { obtenerProveedor } from '../services/ProveedoresServices';
import NavBar from '../components/Navegacion';

function FormularioProducto() {

    // - Alamcenamientos ---------------------------------------------------------------------------

    const [productoSeleccionado, setProductoSeleccionado] = useState(null); // guardara un producto en especifico
    const [nombre, setNombre] = useState(''); // campo del nombre
    const [cantidad, setCantidad] = useState(0); // campo de la catidad
    const [precio, setPrecio] = useState(0); //campo del precio
    const [codigoBarras, setCodigoBarras] = useState(''); //campo del codigo de barras
    const [categoriasSeleccionadas, setCategoriasSeleccionadas] = useState([]);  // Id(s) de categoria(s) seleccionada(s) 
    const [proveedorSeleccionado, setProveedorSeleccionado] = useState(null); // id del proveedor seleccionado

    const [productos, setProductos] = useState([]); // lista de productos
    const [listaCategorias, setListaCategorias] = useState([]); // lista de todas las categoris disponibles
    const [listaProveedores, setListaProveedores] = useState([]); // lista de todos los proveedores

    // --------------------------------------------------------------------------------------------

    //encargado de obtener los productos de la api
    const cargarProductos = () => {
        obtenerProductos()
            .then(data =>  // Verifica qué datos se obtienen
                setProductos(data) // Actualiza el estado con los productos
            )
            .catch(error => console.error("Error al cargar productos:", error));
    };

    // renderizamos las tres listas
    useEffect(() => {
        cargarProductos(); // cargar productos

        obtenerCategorias() // cargar categorias
            .then(setListaCategorias) // guardar en la lista
            .catch(console.error);

        obtenerProveedor() // cargar proveedores
            .then(setListaProveedores) //guardar en la lista
            .catch(console.error);
    }, []);


    // funcion encargada de la creacion
    const manejarCrear = (e) => {
        e.preventDefault(); // previene eventos por predeterminados

        // guardamos el objeto
        const datos = {
            nombre,
            cantidad,
            precio,
            codigoBarras,
            categorias_ids: categoriasSeleccionadas,
            proveedores: proveedorSeleccionado,
        };

        // enviamos los datos a la api
        crearProducto(datos)
            .then(() => {
                cargarProductos() // recargamos la lista

                // Limpiar formulario
                setNombre('');
                setCantidad(0);
                setPrecio(0);
                setCodigoBarras(0);
                setCategoriasSeleccionadas([]);
                setProveedorSeleccionado(null);

                // ocultamos el modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalCrear'));
                if (modal) modal.hide();
            })
            .catch((error) => {
                console.error("Error creando producto:", error);
            });
    };

    // encargada de llenar los datos del modalEditar
    const manejarEditar = (producto) => {
        setProductoSeleccionado(producto); // guardamos el producto actual para luego actualizarlo

        // llenamos los datos para el modal
        setNombre(producto.nombre);
        setCantidad(producto.cantidad);
        setPrecio(producto.precio);
        setCodigoBarras(producto.codigoBarras);

        // traemos los proveedores y categorias en general
        setCategoriasSeleccionadas(producto.categorias.map(cat => cat.id) || []);
        setProveedorSeleccionado(producto.proveedores.id || null);


        // mostramos el modal 
        const modalElement = document.getElementById('modalEditar');
        const modal = bootstrap.Modal.getOrCreateInstance(modalElement); // puesto que me presentaban errores de cargar, el modal siempre lo mandamos como una nueva instancia
        modal.show();
    };

    // encargado de enviar la actualizacion
    const finalizarEditar = (e) => {
        e.preventDefault(); // evita el comportamiento por defecto

        // veificamos que haya si o si un producto seleccionado
        if (!productoSeleccionado) return;

        // cargamos los datos en un nuevo objeto
        const datosActualizados = {
            nombre,
            cantidad,
            precio,
            codigoBarras,
            categorias_ids: categoriasSeleccionadas,
            proveedores: proveedorSeleccionado,
        };

        // llamada a la api
        actualizarProducto(productoSeleccionado.id, datosActualizados)
            .then(() => {
                cargarProductos() // refrescamos la lista
                setProductoSeleccionado(null); // limpiamos el producto seleccionado

                // limpiamos los inputs
                setNombre('');
                setCantidad(0);
                setPrecio(0);
                setCodigoBarras(0);
                setCategoriasSeleccionadas([]);
                setProveedorSeleccionado(null);

                // cerramos el modal
                const modalElement = document.getElementById('modalEditar');
                const modal = bootstrap.Modal.getInstance(modalElement);
                if (modal) modal.hide();
            })
            .catch((error) => {
                console.error("Error al actualizar el producto:", error);
            });
    };

    // encargado de llenar el modal de eliminar
    const manejarEliminar = (producto) => {
        setProductoSeleccionado(producto);
    };

    const confirmarEliminar = () => {

        if (!productoSeleccionado) return; // verificamos que haya un producto seleccioando

        // llamamos la api
        eliminarProducto(productoSeleccionado.id)
            .then(() => {
                cargarProductos(); // recargamos la lista
                setProductoSeleccionado(null); // vaciamos el producto seleccionado

                // cerramos el modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalEliminar'));
                if (modal) modal.hide();
            })
            .catch((error) => {
                console.error("Error al eliminar producto:", error);
            });
    };

    return (
        <div className="bodyFormulario">


            <header>
                <NavBar />
            </header>

            <div className="styled-form mt-5">
                <div className="container">
                    <div className="row justify-content-center align-items-center g-2">
                        <div className="col">
                            <h1>Modulo Productos</h1>
                        </div>
                    </div>

                    <div className="row justify-content-center align-items-center mt-2 g-2">
                        <div className="col">
                            <button
                                type="button"
                                className="btn btn-primary btn-lg mb-3 bx bxs-message-square-add"
                                data-bs-toggle="modal"
                                data-bs-target="#modalCrear"
                            >
                                Agregar
                            </button>
                        </div>
                    </div>

                    <div className="row justify-content-center align-items-center g-2">
                        <div className="col">
                            <div className="table-responsive">
                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Nombre</th>
                                            <th>Cantidad</th>
                                            <th>Precio</th>
                                            <th>Codigo de Barras</th>
                                            <th>Fecha de Ingreso</th>
                                            <th>Categorias</th>
                                            <th>Proveedor</th>
                                            <th>Acciones</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        {productos.map(producto => (
                                            <tr key={producto.id}>
                                                <td>{producto.id}</td>
                                                <td>{producto.nombre}</td>
                                                <td>{producto.cantidad}</td>
                                                <td>{producto.precio}</td>
                                                <td>{producto.codigoBarras}</td>
                                                <td>{producto.fechaIngreso}</td>
                                                <td>{producto.categorias.map(c => c.nombre).join(', ')}</td>
                                                <td>{producto.proveedores}</td>
                                                <td>
                                                    {/* Boton para editar */}
                                                    <button
                                                        className="btn btn-dark bx bx-edit" data-bs-toggle="modal" data-bs-target="#modalEditar" onClick={() => manejarEditar(producto)}
                                                    ></button>
                                                    {" || "}
                                                    {/* Boton para eliminar */}
                                                    <button
                                                        className="btn btn-danger bx bxs-trash " data-bs-toggle="modal" data-bs-target="#modalEliminar" onClick={() => manejarEliminar(producto)}
                                                    ></button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal para crear un producto */}
            <div className="modal fade" id="modalCrear" tabIndex="-1">
                <div className="modal-dialog">
                    <div className="modal-content">

                        <div className="modal-header">
                            <h5 className="modal-title">Agregar Producto</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                        </div>

                        <div className="modal-body">

                            <form id="formularioCrear" onSubmit={manejarCrear}>
                                <div className="mb-3">
                                    <label className="form-label">Nombre</label>
                                    <input type="text" className="form-control" value={nombre}
                                        onChange={(e) => setNombre(e.target.value)} required />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Cantidad</label>
                                    <input type="number" className="form-control" value={cantidad}
                                        onChange={(e) => setCantidad(parseInt(e.target.value))} required />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Precio</label>
                                    <input type="number" className="form-control" value={precio}
                                        onChange={(e) => setPrecio(parseFloat(e.target.value))} required />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Código de Barras</label>
                                    <input type="number" className="form-control" value={codigoBarras}
                                        onChange={(e) => setCodigoBarras(e.target.value)} required />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Categorías</label>
                                    <select required multiple className="form-select"
                                        value={categoriasSeleccionadas}
                                        onChange={(e) => {
                                            const selected = Array.from(e.target.selectedOptions, opt => parseInt(opt.value));
                                            setCategoriasSeleccionadas(selected);
                                        }}>
                                        {listaCategorias.map(cat => (
                                            <option key={cat.id} value={cat.id}>{cat.nombre}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Proveedor</label>
                                    <select required className="form-control" value={proveedorSeleccionado ?? ""}
                                        onChange={(e) => setProveedorSeleccionado(parseInt(e.target.value))}>
                                        <option value="" disabled>Seleccione un proveedor</option>
                                        {listaProveedores.map(prov => (
                                            <option key={prov.id} value={prov.id}>{prov.nombre}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="text-center">
                                    <button type="submit" className="btn btn-primary">Guardar</button>
                                </div>
                            </form>

                        </div>

                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        </div>

                    </div>
                </div>
            </div>

            {/* Modal para editat un producto */}
            <div className="modal fade" id="modalEditar" tabIndex="-1">
                <div className="modal-dialog">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title">Editar Producto</h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div className="modal-body">
                            <form id="formularioEditar" onSubmit={finalizarEditar}>

                                <div className="mb-3">
                                    <label className="form-label">id</label>
                                    <input required type="text" className="form-control" name="idEliminar"
                                        aria-describedby="helpId" value={productoSeleccionado?.id || ''} disabled />
                                </div>

                                <div className="mb-3">
                                    <label className="form-label">Nombre</label>
                                    <input type="text" className="form-control" value={nombre}
                                        onChange={(e) => setNombre(e.target.value)} required />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Cantidad</label>
                                    <input type="number" className="form-control" value={cantidad}
                                        onChange={(e) => setCantidad(parseInt(e.target.value))} required />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Precio</label>
                                    <input type="number" className="form-control" value={precio}
                                        onChange={(e) => setPrecio(parseFloat(e.target.value))} required />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Código de Barras</label>
                                    <input required type="text" className="form-control" value={codigoBarras}
                                        onChange={(e) => setCodigoBarras(e.target.value)} />
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Categorías</label>
                                    <select required multiple className="form-select"
                                        value={categoriasSeleccionadas}
                                        onChange={(e) => {
                                            const selected = Array.from(e.target.selectedOptions, opt => parseInt(opt.value));
                                            setCategoriasSeleccionadas(selected);
                                        }}>
                                        {listaCategorias.map(cat => (
                                            <option key={cat.id} value={cat.id}>{cat.nombre}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="mb-3">
                                    <label className="form-label">Proveedor</label>
                                    <select required className="form-control" value={proveedorSeleccionado ?? ""}
                                        onChange={(e) => setProveedorSeleccionado(parseInt(e.target.value))}>
                                        <option value="" disabled>Seleccione un proveedor</option>
                                        {listaProveedores.map(prov => (
                                            <option key={prov.id} value={prov.id}>{prov.nombre}</option>
                                        ))}
                                    </select>
                                </div>
                                <div className="row justify-content-center align-items-center g-2">
                                    <div className="col">

                                        <button type="submit" className="btn btn-primary">
                                            Guardar
                                        </button>

                                    </div>
                                </div>
                            </form>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal para eliminar un producto */}
            <div className="modal fade" id="modalEliminar" tabIndex="-1" role="dialog" aria-labelledby="modalTitleId"
                aria-hidden="true">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="modalTitleId">
                                Eliminar Producto
                            </h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="container-fluid">
                                <form id="formularioEliminar" onSubmit={confirmarEliminar} >

                                    <div className="mb-3">
                                        <label className="form-label">id</label>
                                        <input required type="text" className="form-control" name="idEliminar"
                                            aria-describedby="helpId" value={productoSeleccionado?.id || ''} disabled />
                                    </div>

                                    <div className="row justify-content-center align-items-center g-2">
                                        <div className="col">

                                            <button type="submit" className="btn btn-danger">
                                                Eliminar
                                            </button>

                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>




        </div>
    );
}

export default FormularioProducto;
