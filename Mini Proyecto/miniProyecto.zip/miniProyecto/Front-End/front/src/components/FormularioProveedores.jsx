import React, { useState, useEffect } from 'react';
import { obtenerProveedor, crearProveedor, actualizarProveedor, eliminarProveedor } from '../services/ProveedoresServices';
import NavBar from '../components/Navegacion'

function FormularioProveedores() {

    // Almacenamientos ----------------------------------------------------------------------

    const [proveedores, setProveedores] = useState([]); // lista de proveedores
    // campos del formualrio
    const [nombre, setNombre] = useState('');
    const [cedulaJuridica, setCedulaJuridica] = useState('');
    const [telefono, setTelefono] = useState('');
    const [correo, setCorreo] = useState('');
    // guarda el proveedor seleccionado (para eliminar o editar)
    const [proveedorSeleccionado, setProveedorSeleccionado] = useState(null);

    // --------------------------------------------------------------------------------------



    // funcion encargada de generar la lista de proveedores
    const cargarProveedores = () => {
        obtenerProveedor() // llamada a la api
            .then(data => setProveedores(data)) // guarda los datos en la lista
            .catch(error => console.error("Error al caragar los proveedores", error));
    };

    // renderiza la lista apenas se abre la pagina
    useEffect(() => {
        cargarProveedores();
    }, []);

    // funcion encargada de realizar la creacion
    const manejarCrear = async (e) => {
        e.preventDefault(); //evita eventos por defecto 

        // creamos el objeto con los datos
        const nuevoProveedor = {
            nombre,
            cedulaJuridica,
            telefono,
            correo
        };

        // llamamos a la api
        crearProveedor(nuevoProveedor)
            .then(() => {
                cargarProveedores(); // volvemos a cargar la lista

                // vaciamos los inputs
                setNombre('');
                setCedulaJuridica('');
                setTelefono('');
                setCorreo('');

                //cerramos el modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalCrear'));
                if (modal) modal.hide();
            })
            .catch(error => {
                console.error("Error al crear el proveedor:", error);
            });
    };

    // encargado de llenar los datos del modal
    const manejarEditar = (proveedor) => {

        setProveedorSeleccionado(proveedor); // selecciona el proveedor correspodiente

        // llenaran los datos del modal
        setNombre(proveedor.nombre);
        setCedulaJuridica(proveedor.cedulaJuridica);
        setTelefono(proveedor.telefono);
        setCorreo(proveedor.correo);
    };

    // encargado de realizar por completo la edicion
    const finalizarEditar = async (e) => {
        e.preventDefault(); // previene eventos por defecto

        if (!proveedorSeleccionado) return; // verifica que si se haya seleccionado un proveedor

        // carga un objeto con los datos 
        const datosActualizados = {
            nombre,
            cedulaJuridica,
            telefono,
            correo
        };

        //llama a la Api
        actualizarProveedor(proveedorSeleccionado.id, datosActualizados)
            .then(() => {

                // recarga la lista
                cargarProveedores();
                setProveedorSeleccionado(null); // vacia el proveddor seleccionado

                //limpia los inputs
                setNombre('');
                setCedulaJuridica('');
                setTelefono('');
                setCorreo('');

                // Cierra el modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalEditar'));
                if (modal) modal.hide();
            })

    };

    // metodo encargado de la eliminacion
    const manejarEliminar = (e) => {
        e.preventDefault();// previene funciones por defecto

        if (proveedorSeleccionado) {//valida que si haya un proveedor sleccionado
            //llama a la api
            eliminarProveedor(proveedorSeleccionado.id)
                .then(() => {
                    cargarProveedores(); //recarga la lista
                    setProveedorSeleccionado(null);// vacia la seleccion

                    //cierra el modal
                    const modalEliminar = bootstrap.Modal.getInstance(document.getElementById('modalEliminar'));
                    if (modalEliminar) modalEliminar.hide();
                })
                .catch(error => console.error("Error al eliminar el proveedor", error));
        }
    }


    return (


        <div className='bodyFormulario'>


            <header>
                <NavBar></NavBar>
            </header>


            <div className="styled-form mt-5">
                <div className="container">

                    {/*!-- Titulo form */}
                    <div className="row justify-content-center align-items-center g-2">
                        <div className="col">
                            <h1>Modulo Proveedores</h1>
                        </div>
                    </div>

                    {/*-- boton agregar-- */}
                    <div className="row justify-content-center align-items-center mt-2 g-2">
                        <div className="col">
                            <button type="button" className="btn btn-primary btn-lg mb-3 bx bxs-message-square-add"
                                data-bs-toggle="modal" data-bs-target="#modalCrear">
                                Agregar
                            </button>
                        </div>
                    </div>

                    {/*-- Table body-- */}
                    <div className="row justify-content-center align-items-center g-2">
                        <div className="col">
                            <div className="table-responsive">
                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Id</th>
                                            <th scope="col">Nombre</th>
                                            <th scope="col">Cedula Juridica</th>
                                            <th scope="col">Telefono</th>
                                            <th scope="col">Correo</th>
                                            <th scope="col">Acciones</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        {/* Recorremos el array de productos y generamos una fila por cada uno */}
                                        {proveedores.map((prov) => (
                                            <tr key={prov.id}>
                                                <td>{prov.id}</td>
                                                <td>{prov.nombre}</td>
                                                <td>{prov.cedulaJuridica}</td>
                                                <td>{prov.telefono}</td>
                                                <td>{prov.correo}</td>
                                                <td>
                                                    {/* Botón para editar */}
                                                    <button
                                                        className="btn btn-dark bx bx-edit" data-bs-toggle="modal" data-bs-target="#modalEditar" onClick={() => manejarEditar(prov)}
                                                    ></button>
                                                    {" || "}
                                                    {/* Botón para eliminar */}
                                                    <button
                                                        className="btn btn-danger bx bxs-trash " data-bs-toggle="modal" data-bs-target="#modalEliminar" onClick={() => setProveedorSeleccionado(prov)}
                                                    ></button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>


                                </table>
                            </div>
                        </div>
                    </div>

                </div>



            </div>

            {/* Modal para crear un proveedor */}
            <div className="modal fade" id="modalCrear" tabIndex="-1" role="dialog" aria-labelledby="modalTitleId"
                aria-hidden="true">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="modalTitleId">
                                Agregar Proveedor
                            </h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="container-fluid">
                                <form id="formularioCrear" onSubmit={manejarCrear}>

                                    <div className="mb-3">
                                        <label className="form-label">Nombre</label>
                                        <input required type="text" className="form-control" name="nombre" value={nombre} onChange={(e) => setNombre(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese nombre" />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Cedula Juridica</label>
                                        <input required type="text" className="form-control" name="cedulaJuridica" value={cedulaJuridica} onChange={(e) => setCedulaJuridica(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese la Cedula Juridica" />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Telefono</label>
                                        <input required type="text" className="form-control" name="telefono" value={telefono} onChange={(e) => setTelefono(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese el Telefono" />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Correo</label>
                                        <input required type="email" className="form-control" name="correo" value={correo} onChange={(e) => setCorreo(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese el Correo" />
                                    </div>

                                    <div className="row justify-content-center align-items-center g-2">
                                        <div className="col">

                                            <button type="submit" className="btn btn-primary">
                                                Guardar
                                            </button>

                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal para editar un proveedor */}
            <div className="modal fade" id="modalEditar" tabIndex="-1" role="dialog" aria-labelledby="modalTitleId"
                aria-hidden="true">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="modalTitleId">
                                Editar Producto
                            </h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="container-fluid">
                                <form id="formularioEditar" onSubmit={finalizarEditar}>

                                    <div className="mb-3">
                                        <label className="form-label">id</label>
                                        <input required type="text" className="form-control" name="idEditar" id="idEditar"
                                            aria-describedby="helpId" value={proveedorSeleccionado?.id || ''} disabled />
                                    </div>

                                    <div className="mb-3">
                                        <label className="form-label">Nombre</label>
                                        <input required type="text" className="form-control" name="nombre" value={nombre} onChange={(e) => setNombre(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese nombre" />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Cedula Juridica</label>
                                        <input required type="text" className="form-control" name="cedulaJuridica" value={cedulaJuridica} onChange={(e) => setCedulaJuridica(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese la Cedula Juridica" />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Telefono</label>
                                        <input required type="text" className="form-control" name="telefono" value={telefono} onChange={(e) => setTelefono(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese el Telefono" />
                                    </div>
                                    <div className="mb-3">
                                        <label required className="form-label">Correo</label>
                                        <input type="email" className="form-control" name="correo" value={correo} onChange={(e) => setCorreo(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese el Correo" />
                                    </div>


                                    <div className="row justify-content-center align-items-center g-2">
                                        <div className="col">

                                            <button type="submit" className="btn btn-primary">
                                                Guardar
                                            </button>

                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal para eliminar un proveedor */}
            <div className="modal fade" id="modalEliminar" tabIndex="-1" role="dialog" aria-labelledby="modalTitleId"
                aria-hidden="true">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="modalTitleId">
                                Editar Producto
                            </h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="container-fluid">
                                <form id="formularioEliminar" onSubmit={manejarEliminar}>

                                    <div className="mb-3">
                                        <label className="form-label">id</label>
                                        <input required type="text" className="form-control" name="idEliminar"
                                            aria-describedby="helpId" value={proveedorSeleccionado?.id || ''} disabled />
                                    </div>

                                    <div className="row justify-content-center align-items-center g-2">
                                        <div className="col">

                                            <button type="submit" className="btn btn-danger">
                                                Eliminar
                                            </button>

                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </div>


    )
}

export default FormularioProveedores