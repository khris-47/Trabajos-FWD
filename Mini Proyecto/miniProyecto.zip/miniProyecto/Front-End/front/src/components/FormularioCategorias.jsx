import React, { useEffect, useState } from 'react';
import { obtenerCategorias, crearCategoria, actualizarCategoria, eliminarCategoria } from '../services/CategoriasServices';

import NavBar from '../components/Navegacion'

function FormularioCategorias() {


    // Almacenamientos -----------------------------------------------------------
    
    const [categorias, setCategorias] = useState([]); // almacenamos la lista de categorias 
    const [categoriaSeleccionada, setCategoriaSeleccionada] = useState(null); // esto se usara para seleccionar una categoria en especifico
    const [nombre, setNombre] = useState(''); // obtener el nombre del form
    const [descripcion, setDescripcion] = useState(''); // obtenerner la descripcion del form

    // ---------------------------------------------------------------------------


    // Usamos el useEffect para renderizar de imediato la funcion para cargar los datos
    useEffect(() => {
        cargarCategorias();
    }, []);

    // llamamos a la api para cargar los datos
    const cargarCategorias = () => {
        obtenerCategorias() // llamada a la api
            .then(data => setCategorias(data)) // los datos obtenidos los ingresamos en la lista de categorias
            .catch(error => console.error("Error al cargar categorias:", error));
    };


    // funcion encargado de la creacion
    const manejarCrear = (e) => {
        e.preventDefault(); // evitamos el comportamiento por defecto de un formulario

        // creamos un objeto con los datos del modal crear
        const datos = {
            nombre,
            descripcion
        };

        // llmada a la api 
        crearCategoria(datos)
            .then(() => {
                cargarCategorias();      // recargar la tabla
                setNombre('');           // limpiar los inputs
                setDescripcion('');
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalCrear'));
                modal.hide();           // cerrar el modal despues de crear
            })
            .catch(error => {
                console.error("Error al crear la categoria:", error);
            });
    };


    // funcion para obtener los datos para el modal de editar
    const manejarEditar = (categoria) => {
        setCategoriaSeleccionada(categoria); // obtiene los datos de la categora seleccionada
        
        // usando la categora seleccionada, rellena el nombre y la descripcion
        setNombre(categoria.nombre); 
        setDescripcion(categoria.descripcion);
    };

    // funcion encargada de hacer la edicion
    const finalizarEditar = (e) => {
        e.preventDefault(); // previene el comportamiento por defecto

        // vuelve a verificar que si haya una categoria seleccionada
        if (!categoriaSeleccionada) return;  // si bien es redundante, es mejor prevenir errores

        // creamos un objeto con los datos del modal
        const datosActualizados = {
            nombre,
            descripcion,
        };

        // llamamos a la api dandole los datos del modal 
        actualizarCategoria(categoriaSeleccionada.id, datosActualizados)
            .then(() => {
                cargarCategorias(); // volvemos a cargar la lista
                setCategoriaSeleccionada(null); // le hacemos un reset a la categoria seleccioanda
                
                //limpiamos campos
                setNombre(''); 
                setDescripcion('');

                // cerramos el modal
                const modal = bootstrap.Modal.getInstance(document.getElementById('modalEditar'));
                modal.hide();
            })
            .catch((error) => console.error('Error al actualizar la categoria:', error));
    };


    // se encarga de la eliminacion
    const manejarEliminar = (e) => {
        e.preventDefault(); // previene el comportamieno por defecto

        if (categoriaSeleccionada) { // verifica que haya una categoria seleccioanda

            eliminarCategoria(categoriaSeleccionada.id) // llamada a la api
                .then(() => {
                    cargarCategorias(); // recarga el form
                    setCategoriaSeleccionada(null); // hace un reset a la categoria seleccionada
                    const modalEliminar = bootstrap.Modal.getInstance(document.getElementById('modalEliminar'));
                    if (modalEliminar) modalEliminar.hide(); // cierra el modal
                })
                .catch(error => console.error("Error al eliminar la categoria:", error));
        }
    }

    return (

        <div className='bodyFormulario'>


            <header>
                <NavBar></NavBar>
            </header>


            <div className="styled-form mt-5">
                <div className="container">

                    {/* Titulo form */}
                    <div className="row justify-content-center align-items-center g-2">
                        <div className="col">
                            <h1>Modulo Categorias</h1>
                        </div>
                    </div>

                    {/* boton agregar */}
                    <div className="row justify-content-center align-items-center mt-2 g-2">
                        <div className="col">
                            <button type="button" className="btn btn-primary btn-lg mb-3 bx bxs-message-square-add"
                                data-bs-toggle="modal" data-bs-target="#modalCrear">
                                Agregar
                            </button>
                        </div>
                    </div>

                    {/*-- Table body-- */}
                    <div className="row justify-content-center align-items-center g-2">
                        <div className="col">
                            <div className="table-responsive">
                                <table className="table">
                                    <thead>
                                        <tr>
                                            <th scope="col">Id</th>
                                            <th scope="col">Nombre</th>
                                            <th scope="col">Descripcion</th>
                                            <th scope="col">Acciones</th>
                                        </tr>
                                    </thead>

                                    <tbody>
                                        {/* Recorremos el array de categorias y generamos una fila por cada uno */}
                                        {categorias.map((cat) => (
                                            <tr key={cat.id}>
                                                <td>{cat.id}</td>
                                                <td>{cat.nombre}</td>
                                                <td>{cat.descripcion}</td>
                                                <td>
                                                    {/* Boton para editar */}
                                                    <button
                                                        className="btn btn-dark bx bx-edit" data-bs-toggle="modal" data-bs-target="#modalEditar" onClick={() => manejarEditar(cat)}
                                                    ></button>
                                                    {" || "}
                                                    {/* Boton para eliminar */}
                                                    <button
                                                        className="btn btn-danger bx bxs-trash " data-bs-toggle="modal" data-bs-target="#modalEliminar" onClick={() => setCategoriaSeleccionada(cat)}
                                                    ></button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>


                                </table>
                            </div>
                        </div>
                    </div>

                </div>



            </div>

            {/* Modal para crear un categoria */}
            <div className="modal fade" id="modalCrear" tabIndex="-1" role="dialog" aria-labelledby="modalTitleId"
                aria-hidden="true">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="modalTitleId">
                                Agregar Categoria
                            </h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="container-fluid">
                                <form id="formularioCrear" onSubmit={manejarCrear}>

                                    <div className="mb-3">
                                        <label className="form-label">Nombre</label>
                                        <input required type="text" className="form-control" name="nombre" value={nombre} onChange={(e) => setNombre(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese el nombre" />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Descripcion</label>
                                        <input required type="text" className="form-control" name="descripcion" value={descripcion} onChange={(e) => setDescripcion(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese la descripcion" />
                                    </div>

                                    <div className="row justify-content-center align-items-center g-2">
                                        <div className="col">

                                            <button type="submit" className="btn btn-primary">
                                                Guardar
                                            </button>

                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal para editar una categoria */}
            <div className="modal fade" id="modalEditar" tabIndex="-1" role="dialog" aria-labelledby="modalTitleId"
                aria-hidden="true">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="modalTitleId">
                                Editar Categoria
                            </h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="container-fluid">
                                <form id="formularioEditar" onSubmit={finalizarEditar}> 

                                    <div className="mb-3">
                                        <label className="form-label">id</label>
                                        <input required type="text" className="form-control" name="idEditar" id="idEditar"
                                            aria-describedby="helpId" value={categoriaSeleccionada?.id || ''} disabled />
                                    </div>

                                    <div className="mb-3">
                                        <label className="form-label">Nombre</label>
                                        <input required type="text" className="form-control" name="nombreEditar" value={nombre} onChange={(e) => setNombre(e.target.value)}
                                            aria-describedby="helpId" placeholder="Ingrese nombre" />
                                    </div>
                                    <div className="mb-3">
                                        <label className="form-label">Cantidad</label>
                                        <input required type="text" className="form-control" name="descripcionEditar" value={descripcion} onChange={(e) => setDescripcion(e.target.value)}
                                            aria-describedby="helpId"
                                            placeholder="Ingrese la descripcion" />
                                    </div>
                                    <div className="row justify-content-center align-items-center g-2">
                                        <div className="col">

                                            <button type="submit" className="btn btn-primary">
                                                Guardar
                                            </button>

                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <div className="modal-footer">
                            <button type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>

            {/* Modal para eliminar una categoria */}
            <div className="modal fade" id="modalEliminar" tabIndex="-1" role="dialog" aria-labelledby="modalTitleId"
                aria-hidden="true">
                <div className="modal-dialog" role="document">
                    <div className="modal-content">
                        <div className="modal-header">
                            <h5 className="modal-title" id="modalTitleId">
                                Eliminar Categoria
                            </h5>
                            <button type="button" className="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div className="modal-body">
                            <div className="container-fluid">
                                <form id="formularioEliminar" onSubmit={manejarEliminar} >

                                    <div className="mb-3">
                                        <label className="form-label">id</label>
                                        <input type="text" className="form-control" name="idEliminar" 
                                            aria-describedby="helpId" value={categoriaSeleccionada?.id || ''} disabled />
                                    </div>

                                    <div className="row justify-content-center align-items-center g-2">
                                        <div className="col">

                                            <button type="submit" className="btn btn-danger">
                                                Eliminar
                                            </button>

                                        </div>
                                    </div>

                                </form>

                            </div>
                        </div>
                        <div className="modal-footer">
                            <button required type="button" className="btn btn-secondary" data-bs-dismiss="modal">
                                Close
                            </button>
                        </div>
                    </div>
                </div>
            </div>

        </div>

    );
}

export default FormularioCategorias;
