import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import '../styles/Menu.css'
import NavBar from '../components/Navegacion'
import logo from '../assets/logo_api.png'


function Menu() {
    return (

        <div className='bodyMenu'>

            <header>
                <NavBar></NavBar>
            </header>


            <main className='mainMenu'>
                <div className="container mt-5">
                    <div className="row align-items-center justify-content-center">
                        {/* Imagen */}
                        <div className="col-md-6 mb-4 mb-md-0 d-flex justify-content-center">
                            <img src={logo} alt="logo api" className="img-fluid" />
                        </div>

                        {/* Contenido */}
                        <div className="col-md-6">
                            <div className="right-container text-center">
                                <h2>Mini proyecto Django</h2>
                                <p>Este sitio web fue creado como parte del mini proyecto personal para FWD, con el objetivo de practicar y aprender sobre el consumo de APIs.</p>
                                <p>En este espacio encontrarás ejemplos de cómo conectar con una APIs de Django a nivel local y mostrar su información de manera simple y clara, así mismo el como hacer un CRUD simple.</p>
                            </div>
                        </div>
                    </div>
                </div>

            </main>

            
        </div>


    )
}

export default Menu
