import React from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import logo from '../assets/logo_api2.png';
import '../styles/Navegacion.css'
import { Link } from 'react-router-dom';

function Navegacion() {
  return (
    <div className='bodyNavegacion'>
      <div  className="container-fluid d-flex flex-wrap justify-content-between align-items-center py-3" id="navbar-container">
        
        <div className="d-flex align-items-center">
          <img src={logo} alt="logo" />
          <span className="h5 mb-0">Manejo Apis</span>
        </div>

        <nav className="nav">
          <Link className="nav-link" to='/' >Inicio</Link>
          <Link className="nav-link" to='/proveedores'>Proovedores</Link>
          <Link className="nav-link" to="/productos" >Productos</Link>
          <Link className="nav-link" to='/categorias'>Categorias</Link>
        </nav>
      </div>
    </div>
  )
}

export default Navegacion