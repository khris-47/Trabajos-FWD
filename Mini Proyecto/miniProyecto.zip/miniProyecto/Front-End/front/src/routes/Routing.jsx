import React from 'react'
import {BrowserRouter as Router, Routes, Route, Navigate} from 'react-router-dom'

import MenuPrincipal from '../pages/MenuPrincipal'
import Productos from '../pages/ModuloProductos'
import Categorias from '../pages/ModuloCategorias'
import Proveedores from '../pages/ModuloProveedores'

function Routing() {
  return (
    <Router>
        <Routes>
            <Route path='/' element={<Navigate to="/menu"/>} />
            <Route path='/menu' element={<MenuPrincipal></MenuPrincipal>}></Route>
            <Route path='/productos' element={<Productos></Productos>}></Route>
            <Route path='/categorias' element={<Categorias></Categorias>}></Route>
            <Route path='/proveedores' element={<Proveedores></Proveedores>}></Route>
        </Routes>
    </Router>
  )
}

export default Routing