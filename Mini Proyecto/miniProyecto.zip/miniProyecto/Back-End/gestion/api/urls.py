from django.urls import path
from .models import *
from .views  import *

urlpatterns = [

    # -- Rutas para la categoria
    path('categoria/',CategoriaListCreateView.as_view(), name='categoria-list-create'),
    path('categoria/<int:pk>/',CategoriaDetailsView.as_view(), name='categoria-update-delete'),

    # -- Rutas para el proveedor
    path('proveedor/', ProveedorListCreateView.as_view(), name= 'proveedor-list-create'),
    path('proveedor/<int:pk>/', ProveedorDetailView.as_view(), name = 'proveedor-update-delete'),
    
    # -- Rutas para Productos
    path('producto/',ProductosListCreateView.as_view(),name = 'producto-list-create'),
    path('producto/<int:pk>/',ProductoDetailsView.as_view(), name= 'producto-update-delete'),

    # -- Rutas para CategoriasProductos
    path('CategoriasProductos/', CateProdListCreateView.as_view(), name='cateprod-list-create'),
    path('CategoriasProductos/<int:pk>/', CateProdDetailsView.as_view(), name='cateprod-update-delete')
    
]

