from rest_framework.generics import ListCreateAPIView,RetrieveUpdateDestroyAPIView
from .models import *
from .serializers import *

# -- Vistas Para Categria --------------------------------------------------------------------------

class CategoriaListCreateView(ListCreateAPIView): 
    queryset = Categorias.objects.all()
    serializer_class = CategoriaSerializer

class CategoriaDetailsView(RetrieveUpdateDestroyAPIView):
    queryset = Categorias.objects.all()
    serializer_class = CategoriaSerializer


# -- Vistas para Proveedores -----------------------------------------------------------------------

class ProveedorListCreateView(ListCreateAPIView):
    queryset =  Proveedores.objects.all()
    serializer_class =  ProveedorSerializer

class ProveedorDetailView(RetrieveUpdateDestroyAPIView):
    queryset =  Proveedores.objects.all()
    serializer_class =  ProveedorSerializer


# -- Vitas para Productos --------------------------------------------------------------------------

class ProductosListCreateView(ListCreateAPIView):
    queryset = Productos.objects.all()
    serializer_class = ProductoSerializer

class ProductoDetailsView(RetrieveUpdateDestroyAPIView):
    queryset = Productos.objects.all()
    serializer_class = ProductoSerializer


# -- Vistas para Para la tabla intermedia CategoriasProductos -------------------------------------

class CateProdListCreateView(ListCreateAPIView):
    queryset =  CategoriasProductos.objects.all()
    serializer_class =  CateProdSerializer

class CateProdDetailsView(RetrieveUpdateDestroyAPIView):
    queryset =  CategoriasProductos.objects.all()
    serializer_class =  CateProdSerializer






