from rest_framework import serializers
from .models import *


# -- Serializer de Categorias ----------------------------------------------
class CategoriaSerializer(serializers.ModelSerializer):
    class Meta: 
        model = Categorias
        fields = '__all__'

    # Validaciones ----------------------------------------------------------

    def validate_nombre(self, value):
        if len(value) < 3:
            raise serializers.ValidationError("El nombre debe tener al menos 3 caracteres.")
        return value

    def validate_descripcion(self, value):
        if len(value) < 5:
            raise serializers.ValidationError("La descripcion debe tener al menos 5 caracteres.")
        return value


# -- Serializer de Proveedores ---------------------------------------------
class ProveedorSerializer(serializers.ModelSerializer):
    class Meta:
        model =  Proveedores
        fields = '__all__'

    # Validaciones ----------------------------------------------------------

    def validate_nombre(self, value):
        if len(value) < 3:
            raise serializers.ValidationError("El nombre debe tener al menos 3 caracteres.")
        return value
    
    def validate_cedulaJuridica(self, value):
        if len(value) < 9:
            raise serializers.ValidationError("La cedula juridica debe tener al menos 9 caracteres.")
        return value
    
    def validate_telefono(self, value):
        if len(value) < 3:
            raise serializers.ValidationError("El telefono debe tener al menos 8 caracteres.")
        return value


# -- Serializer de Productos
class ProductoSerializer(serializers.ModelSerializer):

    # puesto que, en el models usamos ManyToMany entre categorias y productos, necesitamos utilizar el CategoriaSerializer, para ver las categorias asociadas al producto
    #con el many=True dejamos en claro que pueden haber mas de una categoria y con read_only=True, que es un dato el cual no podemos modificar, solo leer o usar en todo caso
    categorias = CategoriaSerializer(many=True, read_only=True)

    # similar a lo de arriba, solo que al ser un query set, esto es lo que vamos a ver/usar para cuando vayamso a crear / editar un producto
    categorias_ids = serializers.PrimaryKeyRelatedField(
        queryset=Categorias.objects.all(), many=True, write_only=True, source='categorias'
    )

    # En resumen, la primera linea nos permitira ver al completo las categorias asociadas a los productos ya creados, y, 
    # la segunda nos permitira usar la(s) categoria(s) al momento de una creacion o edicion

    class Meta:
        model = Productos
        fields = '__all__'

    # Validaciones ----------------------------------------------------------

    def validate_nombre(self,value):
        if len(value) < 3:
            raise serializers.ValidationError("El nombre del producto tiene que tener al menos 3 caracteres.")
        return value
    
    def validate_cantidad(self, value):
        if value < 0:
            raise serializers.ValidationError("La cantidad no puede ser negativa.")
        return value
    def validate_precio(self, value):
        if value < 0:
            raise serializers.ValidationError("El precio no puede ser negativo.")
        return value

# -- Serializer de CategoriasProductos -----------------------------------------
class CateProdSerializer(serializers.ModelSerializer):
    class Meta:
        model = CategoriasProductos
        fields = '__all__'



