from django.db import models


# -- Modelado  de categorias ---------------------------------------------
class Categorias(models.Model):
    nombre = models.CharField(max_length=30)
    descripcion = models.CharField(max_length=120)

    def __str__(self):
        return self.nombre

# -- Modelado de proveedores ---------------------------------------------
class Proveedores(models.Model):
    nombre = models.CharField(max_length=50)
    cedulaJuridica = models.CharField(max_length=30, unique=True)
    telefono =  models.CharField(max_length=30)
    correo = models.EmailField(unique=True)

    def __str__(self):
        return self.nombre

# -- Modelado de Productos ------------------------------------------------
class Productos(models.Model):
    nombre = models.CharField(max_length=50)
    cantidad = models.IntegerField()
    precio =  models.DecimalField(max_digits=10, decimal_places=2)
    codigoBarras = models.IntegerField(unique=True)
    fechaIngreso = models.DateField(auto_now_add=True)
    categorias =  models.ManyToManyField(Categorias, through='CategoriasProductos', related_name='producto')
    proveedores = models.ForeignKey(Proveedores, on_delete=models.CASCADE)

    def __str__(self):
        return self.nombre

# -- Tabla Intermedia entre productos y  categiras ----------------------------
class CategoriasProductos(models.Model):
    categoria = models.ForeignKey(Categorias, on_delete=models.CASCADE)
    producto = models.ForeignKey(Productos, on_delete=models.CASCADE)

    def __str__(self):
        return self.id